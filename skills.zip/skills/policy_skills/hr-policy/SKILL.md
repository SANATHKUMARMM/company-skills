---
name: hr-policy
description: This gives the detailed explanation of HR policy
---

# Employee Handbook and Human Resources Policy

**Company Name:** Acme Corporation  
**Effective Date:** January 1, 2026  
**Last Revised:** September 17, 2026  

---

## 1. Introduction

Welcome to Acme Corporation! We are thrilled to have you on our team. This Employee Handbook is designed to acquaint you with Acme Corporation and provide you with information about working conditions, employee benefits, and some of the policies affecting your employment. You should read, understand, and comply with all provisions of the handbook. 

*Note: This handbook is not a contract of employment, nor is it a legal document. The policies outlined here are subject to change at the sole discretion of Acme Corporation.*

## 2. Employment Policies

### 2.1 At-Will Employment
Your employment with Acme Corporation is voluntarily entered into, and you are free to resign at will at any time, with or without cause. Similarly, Acme Corporation may terminate the employment relationship at will at any time, with or without notice or cause, so long as there is no violation of applicable federal or state law.

### 2.2 Equal Employment Opportunity (EEO)
Acme Corporation is an equal opportunity employer. We prohibit discrimination and harassment of any type and afford equal employment opportunities to employees and applicants without regard to race, color, religion, sex, sexual orientation, gender identity or expression, pregnancy, age, national origin, disability status, genetic information, protected veteran status, or any other characteristic protected by law.

### 2.3 Anti-Harassment and Anti-Bullying
We are committed to providing a work environment free of harassment, bullying, and intimidation. This includes sexual harassment as well as harassment based on any protected characteristic. Any employee who believes they have been harassed should immediately report the incident to their supervisor or the Human Resources Department. All complaints will be investigated promptly and confidentially. Retaliation against any employee for reporting harassment is strictly prohibited.

### 2.4 Disability Accommodation
Acme Corporation complies with the Americans with Disabilities Act (ADA) and applicable state and local laws. We will provide reasonable accommodations to qualified individuals with disabilities unless doing so would create an undue hardship for the company. Employees needing accommodations should contact HR.

---

## 3. Workplace Conduct

### 3.1 Code of Conduct
Employees are expected to conduct themselves in a professional, ethical, and respectful manner at all times. This includes interactions with colleagues, clients, vendors, and the public. Conflicts of interest, theft, insubordination, and dishonesty are grounds for immediate disciplinary action, up to and including termination.

### 3.2 Attendance and Punctuality
Consistent attendance and punctuality are essential for the smooth operation of our business. If you are going to be late or absent, you must notify your direct supervisor as soon as possible, preferably at least one hour before your scheduled start time. Excessive absenteeism or tardiness may result in disciplinary action.

### 3.3 Dress Code
Acme Corporation maintains a "Business Casual" dress code. Employees are expected to dress neatly and appropriately for their roles. If you have meetings with clients or external stakeholders, standard business attire may be required.

### 3.4 Drug and Alcohol-Free Workplace
We are committed to maintaining a safe and productive drug-free workplace. The unlawful manufacture, distribution, dispensation, possession, or use of a controlled substance or alcohol is strictly prohibited on company premises or while conducting company business. 

---

## 4. Compensation and Performance

### 4.1 Pay Periods
Employees are paid on a bi-weekly basis, every other Friday. If a payday falls on a company holiday, employees will be paid on the preceding workday.

### 4.2 Overtime (Non-Exempt Employees)
Non-exempt employees are eligible for overtime pay at a rate of one and one-half times their regular rate of pay for all hours worked in excess of 40 hours in a single workweek. All overtime must be approved in advance by a manager.

### 4.3 Performance Reviews
Acme Corporation conducts formal performance reviews annually. These reviews provide an opportunity for managers and employees to discuss performance goals, areas for improvement, and career development.

---

## 5. Benefits and Leave

### 5.1 Paid Time Off (PTO)
Acme Corporation provides a combined Paid Time Off (PTO) bank that covers vacation, personal days, and sick leave. PTO accrues per pay period based on the employee's length of service:
*   **0-2 Years:** 15 days per year
*   **3-5 Years:** 20 days per year
*   **6+ Years:** 25 days per year

PTO requests should be submitted to your supervisor at least two weeks in advance for planned absences.

### 5.2 Paid Holidays
Acme Corporation observes the following paid holidays:
*   New Year’s Day
*   Martin Luther King Jr. Day
*   Memorial Day
*   Independence Day
*   Labor Day
*   Thanksgiving Day
*   Day after Thanksgiving
*   Christmas Day

### 5.3 Parental Leave
Eligible employees receive up to 12 weeks of paid parental leave for the birth, adoption, or foster placement of a child. This leave must be taken within the first 12 months following the child's arrival.

### 5.4 Bereavement Leave
Employees are granted up to three (3) days of paid leave in the event of the death of an immediate family member (spouse, child, parent, sibling, grandparent, or parent-in-law).

---

## 6. Technology and Security

### 6.1 Acceptable Use of Technology
Company-provided equipment (laptops, phones, software) is intended for business purposes. While incidental personal use is permitted, it must not interfere with your work or violate any company policies. 

### 6.2 No Expectation of Privacy
Employees should have no expectation of privacy when using company networks, devices, or email accounts. Acme Corporation reserves the right to monitor, access, and review all communications and data stored on or transmitted through company systems.

### 6.3 Social Media Policy
Employees must not represent their personal opinions as those of the company on social media. Avoid sharing confidential company information, client data, or engaging in online behavior that could damage the company's reputation or violate our anti-harassment policies.

---

## 7. Separation of Employment

### 7.1 Resignation
We request that employees provide a minimum of two weeks' written notice before resigning. This allows for a smooth transition of responsibilities.

### 7.2 Return of Company Property
Upon termination of employment (voluntary or involuntary), employees must return all company property, including keys, laptops, mobile devices, ID badges, and any confidential documents, on or before their final day of work.

---

## 8. Acknowledgment of Receipt

*I have received a copy of the Acme Corporation Employee Handbook. I understand that it is my responsibility to read and comply with the policies contained in this handbook and any revisions made to it.*

*I further understand that this handbook is not a contract of employment and does not alter my at-will employment status.*

**Employee Name (Printed):** ___________________________

**Employee Signature:** ______________________________

**Date:** ________________________________________