---
name: financial-policy
description: This gives the detailed explanation of financial policy
---
# Financial Policy and Procedures Manual

**Company Name:** Nexus Tech Consulting
**Effective Date:** September 17, 2026
**Last Revised:** September 17, 2026

## 1. Introduction and Purpose

The purpose of this Financial Policy and Procedures Manual is to establish standard guidelines for the financial operations of Nexus Tech Consulting. As an IT consultancy, our financial health relies heavily on accurate project tracking, timely invoicing, and strict expense management. These policies are designed to safeguard company assets, ensure accurate financial reporting, and maintain compliance with Generally Accepted Accounting Principles (GAAP) and relevant tax regulations.

This policy applies to all employees, contractors, and partners of Nexus Tech Consulting.

## 2. Revenue Recognition

Nexus Tech Consulting generates revenue through various engagement models. Revenue must be recognized accurately based on the nature of the contract.

### 2.1 Time and Materials (T&M) Engagements
For T&M contracts, revenue is recognized based on the actual billable hours worked by consultants and the direct expenses incurred, as outlined in the Statement of Work (SOW). 
* Timesheets must be approved by the client and submitted to the Finance Department by close of business every Friday.
* Unbilled revenue (Accrued Revenue) will be recognized at month-end for hours worked but not yet invoiced.

### 2.2 Fixed-Price Engagements
For fixed-price contracts, revenue is recognized using the Percentage of Completion (POC) method or upon the delivery of specific, agreed-upon project milestones.
* Project Managers must report project completion percentages to the Finance Department on the 25th of each month.
* Milestone sign-offs from the client must be attached to the invoicing request.

### 2.3 Managed IT Services (Retainers)
Revenue from recurring managed services or support retainers is recognized on a straight-line basis over the term of the contract, regardless of the specific hours utilized in a given month, unless otherwise stipulated in the Master Services Agreement (MSA).

## 3. Client Invoicing and Accounts Receivable

Timely billing is critical to maintaining healthy cash flow.

### 3.1 Invoicing Schedule
* **T&M Projects:** Invoiced bi-weekly or monthly, as dictated by the client contract.
* **Fixed-Price Projects:** Invoiced within 48 hours of milestone approval.
* **Managed Services:** Invoiced on the 1st of the month for that month's services (in advance).

### 3.2 Payment Terms
Standard payment terms are Net 30 days from the date of the invoice unless otherwise negotiated by the Executive Team and documented in the MSA.

### 3.3 Collections and Late Fees
* The Finance Department will send friendly reminders at 15 days past due.
* Accounts exceeding 30 days past due will prompt a suspension warning.
* Nexus Tech Consulting reserves the right to apply a 1.5% monthly late fee to unpaid balances exceeding 45 days, and to suspend ongoing consulting services until the account is made current.

## 4. Timesheet and Utilization Policy

Accurate time tracking is the foundation of our revenue and payroll cycles.

### 4.1 Timesheet Submission
All billable and non-billable employees must log their hours daily in the company's time-tracking software. Timesheets must be submitted for approval no later than 5:00 PM local time on Friday of each week. 

### 4.2 Billable Utilization Targets
Consultants are expected to maintain a minimum billable utilization rate of 75% per quarter. Time spent on internal training, bench time, and administrative tasks must be properly categorized.

## 5. Expense Management

This section outlines reimbursable expenses incurred by employees while conducting business on behalf of Nexus Tech Consulting or our clients.

### 5.1 Travel Expenses
All project-related travel must be pre-approved by the Project Manager and, if billable to the client, must align with the client's specific travel policy.
* **Airfare:** Booked at least 14 days in advance. Economy class is standard for flights under 6 hours.
* **Lodging:** Standard corporate rates apply. Luxury accommodations are not permitted.
* **Per Diem:** Employees are provided a daily per diem for meals and incidentals when traveling overnight, based on standard GSA rates for the destination city.

### 5.2 Software and Technology Purchases
All software subscriptions (e.g., AWS, Azure, SaaS tools) must be approved by the IT Director and Finance. Individual employees may not purchase software licenses on personal credit cards and expense them without prior written authorization.

### 5.3 Expense Reporting
Expense reports must be submitted within 30 days of the incurred expense. Receipts must be provided for all transactions exceeding $25. Reports are processed and reimbursed bi-weekly.

## 6. Accounts Payable and Contractor Payments

### 6.1 Vendor Payments
All vendor invoices must be matched with an approved Purchase Order (PO). Standard vendor payment terms are Net 45 unless otherwise contracted.

### 6.2 Subcontractors and Freelancers
IT contractors and freelancers must submit their invoices and corresponding timesheets by the 3rd business day of the month for the prior month's work. Invoices will only be paid once the corresponding client work has been verified by the internal Project Manager.

## 7. Budgeting and Project Profitability

### 7.1 Annual Budget
The Finance Department will prepare an annual operating budget in Q4 for the upcoming fiscal year. Department heads are responsible for managing their expenditures within the approved budget limits.

### 7.2 Project Margins
Project Managers must review the profitability of their active engagements monthly. The target gross margin for consulting projects is 40%. Any project falling below a 30% margin must be flagged for review by the Director of Delivery and the CFO.

## 8. Audits and Internal Controls

* **Segregation of Duties:** No single individual shall have complete control over all phases of a significant financial transaction. 
* **Access Controls:** Access to accounting software, banking portals, and sensitive financial data is restricted based on role and requires two-factor authentication (2FA).
* **Audits:** The company will undergo an annual financial review by an independent, third-party Certified Public Accounting (CPA) firm.