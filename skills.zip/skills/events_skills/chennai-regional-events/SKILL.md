---
name: chennai-regional-events
description: Use this skill to know about the regional events in Chennai
---
# Nexus Tech Consulting: Chennai Regional Events Schedule

**Location:** Chennai Delivery Center (OMR IT Expressway & Guindy Hub)
**Timeframe:** Q4 2026 – Q3 2027
**Document Version:** 1.0 (Published September 2026)
**Managed By:** Chennai Employee Engagement & Regional HR Team

## Overview and Welcome

Welcome to the 2026-2027 Events Calendar for the Nexus Tech Consulting Chennai region! As one of our fastest-growing global delivery centers, the Chennai office is a hub of technical excellence and vibrant culture. 

This schedule outlines our localized events, ranging from technical upskilling workshops and external tech community meetups to campus hiring drives, CSR initiatives, and our much-anticipated cultural celebrations.

**Event Type Legend:**

* **\[INT-C\]** - Internal Cultural / Social Event
* **\[INT-T\]** - Internal Tech, Training, or Town Hall
* **\[EXT-H\]** - External Hiring / Campus Drive
* **\[EXT-I\]** - External Industry Conference / Tech Meetup
* **\[CSR\]** - Corporate Social Responsibility Initiative

---

## Q4 2026 (October - December)

| Date | Event Name | Location | Type | Target Audience | Description | 
| :--- | :--- | :--- | :--- | :--- | :--- | 
| **Oct 15** | Chennai Q3 Regional Town Hall | Guindy Office, Main Cafeteria | \[INT-T\] | All Chennai Employees | Regional business updates, project spotlights, and Q3 Star Performer awards presented by the India VP of Delivery. | 
| **Oct 30** | Deepavali Mega Celebration | OMR Campus & Guindy Hub | \[INT-C\] | All Chennai Employees | Traditional attire day, bay decoration contest, sweet distribution, and an evening cultural program featuring employee performances. | 
| **Nov 10-12** | NASSCOM GCC Conclave (Delegation) | ITC Grand Chola, Chennai | \[EXT-I\] | Directors, Practice Leads | Nexus Tech will have a 15-person delegation attending this premier event focusing on Global Capability Centers and deep-tech innovation in India. | 
| **Nov 24** | Cloud-Native Meetup: Chennai Chapter | OMR Campus, Auditorium | \[EXT-I\] | Open to Public, Cloud Engineers | Nexus Tech is hosting the local Kubernetes & Cloud-Native community. Two of our Senior Architects will present on "Multi-Cloud FinOps". | 
| **Dec 5** | Tier-1 Campus Recruitment Drive | IIT Madras & Anna University | \[EXT-H\] | Hiring Managers, Senior Tech Leads | Day-zero recruitment drive targeting full-stack developers and data science freshers for the 2027 intake. | 
| **Dec 18** | End of Year / Christmas Bash | Taj Fisherman's Cove Resort | \[INT-C\] | All Chennai Employees | Offsite gala dinner, DJ, and team-building activities to wrap up a successful 2026. Transport from both offices will be provided. | 

---

## Q1 2027 (January - March)

| Date | Event Name | Location | Type | Target Audience | Description | 
| :--- | :--- | :--- | :--- | :--- | :--- | 
| **Jan 12** | Pongal Vizha 2027 | OMR Campus, Open Courtyard | \[INT-C\] | All Chennai Employees | Traditional Pongal celebration including Uriadi, Rangoli (Kolam) competitions, Parai drumming, and a traditional festive lunch served on banana leaves. | 
| **Jan 22** | Agile Masterclass Workshop | Guindy Office, Training Rooms A&B | \[INT-T\] | Project Managers, Scrum Masters | A full-day intensive workshop hosted by external Agile coaches focusing on scaling Agile for enterprise consulting projects. | 
| **Feb 14** | Hackathon: "AI for Social Good" | Virtual & OMR Campus | \[INT-T\] | Developers, Data Engineers | A 24-hour internal hackathon to develop generative AI prototypes aimed at solving local civic issues. Winning team gets a cash prize and funding to deploy. | 
| **Feb 28** | National Science Day CSR | Various Local Govt. Schools | \[CSR\] | Employee Volunteers | Volunteer drive to conduct basic coding and robotics workshops for middle school students in the Velachery and Thoraipakkam areas. | 
| **Mar 8** | International Women's Day Summit | ITC Grand Chola, Chennai | \[INT-C\] | All Chennai Women Employees & Allies | Half-day summit featuring panel discussions with leading women in tech across Tamil Nadu, networking, and leadership workshops. | 
| **Mar 20** | AWS Community Day Chennai | Chennai Trade Centre | \[EXT-I\] | AWS Practitioners, Cloud Team | Nexus Tech is a Gold Sponsor. We will have a booth and two speaking slots. Looking for volunteers to manage the booth and network with talent. | 

---

## Q2 2027 (April - June)

| Date | Event Name | Location | Type | Target Audience | Description | 
| :--- | :--- | :--- | :--- | :--- | :--- | 
| **Apr 13** | Tamil New Year (Puthandu) Lunch | Both Offices | \[INT-C\] | All Chennai Employees | Special festive lunch menu available in all office cafeterias to mark the Tamil New Year. | 
| **Apr 28** | Q1 Regional Town Hall & QBR | Virtual (Teams) | \[INT-T\] | All Chennai Employees | First-quarter business review, update on the 2027 hiring roadmap, and promotion announcements. | 
| **May 15** | Data & Analytics Summit Showcase | OMR Campus, Auditorium | \[INT-T\] | Data Practice, Account Execs | Internal showcase where the Data Practice team demonstrates their latest PowerBI and Snowflake case studies to the wider consultancy team. | 
| **Jun 5** | World Environment Day: Coastal Clean-up | Marina & Elliot's Beach | \[CSR\] | Employee Volunteers | Partnering with local NGOs for an early morning beach clean-up drive. T-shirts, gloves, and breakfast will be provided for all volunteers. | 
| **Jun 25** | Mid-Year Tech Leadership Mixer | Crowne Plaza, Adyar Park | \[EXT-I\] | VPs, Directors, Client Partners | An exclusive invite-only networking dinner bringing together Nexus Tech leadership and key client stakeholders based in Chennai. | 

---

## Q3 2027 (July - September)

| Date | Event Name | Location | Type | Target Audience | Description | 
| :--- | :--- | :--- | :--- | :--- | :--- | 
| **Jul 14** | Campus Fresher Onboarding Week | OMR Campus | \[INT-T\] | New Grads, Mentors, HR | Welcome week for the 2027 campus hires. Includes boot camps, buddy assignments, and leadership meet-and-greets. | 
| **Aug 15** | Independence Day Flag Hoisting | Guindy Office | \[INT-C\] | Open to all Employees | Morning flag hoisting ceremony by the Regional VP, followed by breakfast and a cultural showcase. | 
| **Aug 22** | Madras Day Celebrations | Both Offices | \[INT-C\] | All Chennai Employees | Celebrating the founding of the city with a Chennai-themed photo contest, local street food festival in the cafeteria, and a heritage quiz. | 
| **Sep 10-11** | React India / Frontend Conf | Chennai (Venue TBD) | \[EXT-I\] | UI/UX Designers, React Devs | Sending a delegation to the regional frontend development conference to learn about upcoming web standards and micro-frontend architectures. | 
| **Sep 28** | Q2 Regional Town Hall | Guindy Office, Main Cafeteria | \[INT-T\] | All Chennai Employees | Reviewing Q3 targets, upcoming festive leave planning, and major project go-live celebrations. | 

---

## Participation Guidelines & Contact Information

**Internal Tech & Cultural Events:**
Unless marked otherwise, registration for internal events will open via the **NexusConnect Hub** intranet portal two weeks prior to the event date. Please RSVP to ensure accurate food and beverage counts.

**Volunteering for External/CSR Events:**
Employees wishing to volunteer for Beach Clean-ups, School Coding Drives, or Booth Duty at industry events should seek approval from their direct reporting manager before registering. Volunteering hours can be logged against your annual CSR goals.

**Regional Contact Points:**
*   **Event Suggestions & Feedback:** `chennai-engagement@nexustech.com`
*   **Facilities/Security for Events:** `chennai-facilities@nexustech.com`
*   **HR Queries:** `hr-chennai@nexustech.com`

*Dates and venues are subject to change. Please monitor local Slack channels (`#chennai-office-updates`) for the most current information.*