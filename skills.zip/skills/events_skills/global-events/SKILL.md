---
name: global-events
description: Use this skill to know about the global events
---
# Nexus Tech Consulting: Global Events & Conference Schedule
**Timeframe:** Q4 2026 – Q3 2027
**Document Version:** 1.0 (Published September 2026)
**Managed By:** Global Marketing & Internal Communications Team

---

## Overview
This document outlines the official global events schedule for Nexus Tech Consulting for the upcoming 12 months. It includes major industry conferences we are sponsoring or attending, as well as mandatory and optional internal company events. 

Employees interested in attending external conferences representing Nexus Tech Consulting should contact their Practice Lead and the Global Marketing Team for registration codes, travel approval, and booth duty assignments.

**Event Type Legend:**
* **[INT]** - Internal Company Event (Employees only)
* **[EXT-S]** - External Industry Event (Nexus is Sponsoring/Exhibiting)
* **[EXT-A]** - External Industry Event (Nexus is Attending/Speaking)
* **[CLI]** - Client-focused Event or Mixer

---

## Q4 2026 (October - December)

| Date | Event Name | Location | Type | Target Audience | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Oct 12-16** | GITEX Global 2026 | Dubai, UAE | [EXT-S] | Cloud & AI Practice Leads, Regional Sales | We will have a Tier 1 booth in the AI Pavilion. Volunteers needed for product demos. |
| **Oct 22** | Q3 Global Town Hall | Virtual (Zoom) | [INT] | All Global Employees | Quarterly business review, financial updates, and Q3 award recognitions. (Mandatory) |
| **Nov 2-5** | Web Summit 2026 | Lisbon, Portugal | [EXT-A] | Executive Team, Startup Advisory Group | Networking and scouting emerging technologies. Our CEO is participating in a panel on "The Future of IT Consultancy". |
| **Nov 18** | APAC Client Mixer | Singapore | [CLI] | APAC Clients, Regional Account Managers | An exclusive evening networking event for top-tier clients in the APAC region. |
| **Nov 30 - Dec 4**| AWS re:Invent 2026 | Las Vegas, NV, USA | [EXT-S] | AWS Certified Engineers, Cloud Architects | Our largest sponsorship of the year. We are hosting two breakout sessions and a VIP client dinner. |
| **Dec 15** | Nexus Global Holiday Gala | Regional Hubs | [INT] | All Regional Employees | In-person end-of-year celebrations held simultaneously across our London, New York, Bengaluru, and Sydney offices. |

---

## Q1 2027 (January - March)

| Date | Event Name | Location | Type | Target Audience | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Jan 11-13** | Annual Leadership Summit | Kyoto, Japan | [INT] | Directors, VPs, and C-Suite | Strategic planning for 2027, budget alignments, and leadership workshops. |
| **Jan 27** | Q4/EOY Global Town Hall | Virtual (Zoom) | [INT] | All Global Employees | 2026 Year-in-Review and rollout of the 2027 corporate strategy. |
| **Feb 15-18** | Mobile World Congress (MWC) | Barcelona, Spain | [EXT-A] | Telco & IoT Practice Teams | Focus on 5G/6G deployments, edge computing, and mobile security consulting opportunities. |
| **Feb 24-25** | Internal CyberSec Symposium | Virtual (Teams) | [INT] | Security Engineers, Pentesters | Two-day internal knowledge-sharing event focused on the latest threat landscapes and zero-trust architectures. |
| **Mar 12-16** | SXSW Interactive 2027 | Austin, TX, USA | [EXT-A] | UX/UI Designers, Innovation Team | Exploring the intersection of design, culture, and technology. |
| **Mar 25** | European Client Summit | London, UK | [CLI] | EMEA Clients, Delivery Managers | A half-day summit featuring case studies from our most successful European digital transformation projects. |

---

## Q2 2027 (April - June)

| Date | Event Name | Location | Type | Target Audience | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Apr 6-9** | RSA Conference 2027 | San Francisco, USA | [EXT-S] | Cybersecurity Practice, Sales | Exhibiting our Managed Security Services (MSSP) portfolio. |
| **Apr 22** | Q1 Global Town Hall | Virtual (Zoom) | [INT] | All Global Employees | Quarterly updates, introduction of new hires, and project spotlight presentations. |
| **May 7-9** | Nexus Global Hackathon | Hybrid (All Hubs) | [INT] | Developers, Architects, Data Scientists | 48-hour internal hackathon focused on building generative AI solutions for internal process optimization. |
| **May 25-27** | Microsoft Build 2027 | Seattle, WA, USA | [EXT-A] | .NET Developers, Azure Architects | Deep technical training and networking. We have a quota of 25 delegate passes for senior engineers. |
| **Jun 8-10** | London Tech Week | London, UK | [EXT-S] | UK/EMEA Teams, FinTech Leads | Sponsoring the FinTech and Enterprise Transformation tracks. |
| **Jun 22** | Women in Tech Global Forum | Virtual (Hopin) | [INT] | All Employees | Internal panel discussions, external guest speakers, and mentorship networking. |

---

## Q3 2027 (July - September)

| Date | Event Name | Location | Type | Target Audience | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Jul 14-16** | Cloud Computing Expo | Tokyo, Japan | [EXT-S] | APAC Cloud Practice, Sales | Showcasing our multi-cloud migration frameworks to the Japanese and wider Asian market. |
| **Jul 29** | Q2 Global Town Hall | Virtual (Zoom) | [INT] | All Global Employees | Mid-year check-in on company goals and OKRs. |
| **Aug 7-12** | Black Hat USA 2027 | Las Vegas, NV, USA | [EXT-A] | Red Team, Cyber Threat Analysts | Sending 10 of our top security researchers for advanced training and briefing sessions. |
| **Sep 14-16** | Salesforce Dreamforce 2027| San Francisco, USA | [EXT-S] | CRM Practice, Account Execs | Exhibiting as a Gold Partner. Hosting a masterclass on custom Apex integrations. |
| **Sep 28** | North America Client Mixer | New York, NY, USA | [CLI] | NAM Clients, Regional VPs | High-level networking dinner focusing on the financial and healthcare verticals. |

---

## Registration and Participation Guidelines

* **Internal Events:** Calendar invites for Town Halls and internal symposiums will be sent out automatically by the Internal Communications team.
* **Sponsorship Booth Duty:** If you are selected to staff a booth at an `[EXT-S]` event, you will be required to complete a 2-hour "Booth Etiquette and Pitch Training" session prior to travel.
* **Delegate Passes:** If you wish to attend an `[EXT-A]` event using one of the company's allocated passes, please submit a brief business case (max 200 words) to your Practice Director at least 60 days prior to the event.

*For any questions regarding this schedule, please contact `events@nexustechconsulting.com`.*